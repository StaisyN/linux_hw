import java.awt.image.ConvolveOp;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1 Дана длина в метрах.
        // Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
        // Выведите начальное и конвертированные значения на экран.
        // 1 km -> 1000 м.
        // 1 метр -> 0.000621371 мили
        // 1 метр ->  3.28084 фуnта
        // 1 аршин -> 0.7112 метра

        System.out.println("Введите длину в метрах: ");
        Scanner scr = new Scanner(System.in);
        double metr = scr.nextDouble();
        System.out.printf("длина в km %f km , ", metr/1000);
        System.out.printf("длина в mili %.2f mili , ", metr*0.000621371);
        System.out.printf("длина в funt %.2f funt , ", metr*3.28084);
        System.out.printf("длина в arshin %f arschin. ", metr/0.7112);

        }
 }

