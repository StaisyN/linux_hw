import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
        // которую дал покупатель.Выведите сумму сдачи в виде “X рублей и Y копеек”

        System.out.println("Enter amount of purchase RUB ");
        Scanner scr = new Scanner(System.in);
        int amt = scr.nextInt();
        System.out.println("Enter amount of purchase Kopeek ");
        Scanner scr1 = new Scanner(System.in);
        int amt1 = scr.nextInt();
        System.out.println("Enter purchase of money RUB ");
        Scanner scr2 = new Scanner(System.in);
        int mny = scr.nextInt();
        System.out.println("Enter purchase of money Kopeek ");
        Scanner scr3 = new Scanner(System.in);
        int mny1 = scr.nextInt();


        System.out.println("Your change RUB and " + (mny-amt));
        System.out.println("Your change Kopeek. " + (mny1 - amt1));






    }
}